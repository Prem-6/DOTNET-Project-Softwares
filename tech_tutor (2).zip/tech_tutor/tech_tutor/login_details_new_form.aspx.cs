﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class login_details_new_form : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Visible = false;
    }
    protected void ButtonSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Tech_technologyConnectionString"].ConnectionString);
            con.Open();
            String insertqr = "insert into user_details(User_name,Password,Hint_question,Hint_answer,Status)values(@User_name,@Password,@Hint_question,@Hint_answer,@Status)";
            cmd = new SqlCommand(insertqr, con);
            cmd.Parameters.AddWithValue("@User_name", TextBoxUser_name.Text);
            cmd.Parameters.AddWithValue("@Password", TextBoxPassword.Text);
            cmd.Parameters.AddWithValue("@Hint_question", TextBoxHint_question.Text);
            cmd.Parameters.AddWithValue("@Hint_answer", TextBoxHint_answer.Text);
            cmd.Parameters.AddWithValue("@status", TextBoxStatus.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            Label1.Text = "registered succ";
            Label1.Visible = true;
            TextBoxUser_name.Text = "";
            TextBoxPassword.Text = "";
            TextBoxHint_question.Text = "";
            TextBoxHint_answer.Text = "";
            TextBoxStatus.Text = "";
           
        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
      }
    protected void ButtonCancel_Click(object sender, EventArgs e)
    {
            TextBoxUser_name.Text = "";
            TextBoxPassword.Text="";
            TextBoxHint_question.Text="";
            TextBoxHint_answer.Text="";
            TextBoxStatus.Text="";

    }
}