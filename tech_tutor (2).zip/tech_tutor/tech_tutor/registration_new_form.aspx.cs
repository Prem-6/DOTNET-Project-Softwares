﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


public partial class registration_new_form : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Visible = false;
       Label2.Visible = false;
       Label3.Visible = false;
    }
    protected void ButtonSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Tech_technologyConnectionString"].ConnectionString);
            con.Open();
            String insertqr = "insert into registration_details(First_name,Last_name,Address,Contact_no,Email_id,City,State)values(@First_name,@Last_name,@Address,@Contact_no,@Email_id,@City,@State)";
            cmd = new SqlCommand(insertqr, con);
            cmd.Parameters.AddWithValue("@First_name", TextBoxFirst_name.Text);
            cmd.Parameters.AddWithValue("@Last_name", TextBoxLast_name.Text);
            cmd.Parameters.AddWithValue("@Address", TextBoxAddress.Text);
            cmd.Parameters.AddWithValue("@Contact_no", TextBoxContact_no.Text);
            cmd.Parameters.AddWithValue("@Email_id", TextBoxEmail_id.Text);
            cmd.Parameters.AddWithValue("@City", TextBoxCity.Text);
            cmd.Parameters.AddWithValue("@State", TextBoxState.Text);
            cmd.ExecuteNonQuery();
            con.Close();

            con.Open();
            SqlCommand cmd1;
            string qry = "insert into user_details(User_name,Password)values(@User_name,@Password)";
            cmd1 = new SqlCommand(qry,con);
            cmd1.Parameters.AddWithValue("@User_name", TextBoxFirst_name.Text);
            cmd1.Parameters.AddWithValue("@Password", TextBoxContact_no.Text);
            cmd1.ExecuteNonQuery();
            con.Close();
            Label2.Visible = true;
            Label1.Visible = true;
            Label3.Visible = true;
            Label1.Text = "User Registered Succesfully";
            Label2.Text = "User name is:" + TextBoxFirst_name.Text;
            Label3.Text = "Password is:" + TextBoxContact_no.Text;
            //Label1.Text = "registered succ";
            //Label1.Visible = true;
            TextBoxFirst_name.Text = "";
            TextBoxLast_name.Text = "";
            TextBoxAddress.Text = "";
            TextBoxContact_no.Text = "";
            TextBoxEmail_id.Text = "";
            TextBoxCity.Text = "";
            TextBoxState.Text = "";

        }
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }
    protected void ButtonCancel_Click1(object sender, EventArgs e)
    {
        TextBoxFirst_name.Text = "";
        TextBoxLast_name.Text = "";
        TextBoxAddress.Text = "";
        TextBoxContact_no.Text = "";
        TextBoxEmail_id.Text = "";
        TextBoxCity.Text = "";
        TextBoxState.Text = "";
        Response.Redirect("mainhome.aspx");
    }
}
    
