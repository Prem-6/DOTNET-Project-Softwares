﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


public partial class tech_details_new_form : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Visible = false;
    }
    protected void ButtonSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Tech_technologyConnectionString"].ConnectionString);
            con.Open();
            String insertqr = "insert into tech_details(Tech_name,Tech_description,Used_language,Video_url)values(@Tech_name,@Tech_description,@Used_language,@Video_url)";
            cmd = new SqlCommand(insertqr, con);
            cmd.Parameters.AddWithValue("@Tech_name", TextBoxTech_name.Text);
            cmd.Parameters.AddWithValue("@Tech_description", TextBoxTech_description.Text);
            cmd.Parameters.AddWithValue("@Used_language", ListBox1.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@Video_url", TextBoxVideo_url.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            Label1.Text = "registered succ";
            Label1.Visible = true;
            TextBoxTech_name.Text = "";
            TextBoxTech_description.Text = "";
            //TextBoxUsed_language.Text="";
            TextBoxVideo_url.Text = "";
}
        catch (Exception ex)
        {
            Response.Write(ex);
        }
    }

    protected void ButtonCancel_Click(object sender, EventArgs e)
    {
        TextBoxTech_name.Text = "";
        TextBoxTech_description.Text = "";
        //TextBoxUsed_language.Text="";
        TextBoxVideo_url.Text = "";
    }
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
